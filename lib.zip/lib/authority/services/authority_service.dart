import '../models/authority_sos.dart';
import 'mock_sos_data.dart';

class AuthorityService {
  Future<List<AuthoritySOS>> fetchSOS() async {
    return mockSOS;
  }

  Future<void> acceptSOS(AuthoritySOS sos) async {
    sos.status = "Accepted";
  }

  Future<void> resolveSOS(AuthoritySOS sos) async {
    sos.status = "Resolved";
  }
}
